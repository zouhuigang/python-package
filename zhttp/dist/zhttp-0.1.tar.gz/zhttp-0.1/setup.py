from setuptools import setup
setup(name='zhttp',
      version='0.1',
      description='zouhuigang zhttp package ',
      url='http://github.com/zouhuigang',
      author='zouhuigang',
      author_email='zouhuigang888@gmail.com',
      license='MIT',
      packages=['zhttp'],
      zip_safe=False)